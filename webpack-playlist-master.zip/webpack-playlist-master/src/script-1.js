// Welcome Component JS
var message = require('./script-2');
require('./css/introComponent.scss');
