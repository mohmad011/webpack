const mssg = "tempus fugit";
module.exports = mssg;
